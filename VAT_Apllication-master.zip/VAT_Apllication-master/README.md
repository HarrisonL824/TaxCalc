# VAT_Apllication
#Calculate price with and without VAT
Practice: VAT Application


You must  write  a  program  using  the  same  procedure  as  we discussed.  When  you  opens  the  program  in  the  emulator,  you  should  get  a  window  as  shown  below  that  contains  the  following  widgets:
-a LinearLayout
-a TextView
-an EditText
-a ButtonGroup  with  two  RadioButton  widgets
-a LinearLayout  with  two  Button  widgets
-a TextView
-an EditText
-a TextView
-an EditText
-a TextView
-an EditText

In  the  top  entry  field  you  must  be  able  to  enter  a  unit  price,  while  in  the  next  one  must  be  able  to  enter  the  number  of  units.  When  clicking  on  the  OK  button,  the  application  must  calculate  the  total  price  without  VAT  (depending  on  which  radio  button  is  pressed),  the VAT and total price with VAT, and then the three lower entry fields must be updated.


If  you  press  the  Clear  button,  all  input  fields  must  be  blanked.
When  you  solve  the  exercise,  you  should  place  texts  in  the  file  strings.xml  in  the  same  way  as  we discussed. 
The three bottom entry fields should in principle be read only. Try to find out how to do that
![image](https://user-images.githubusercontent.com/101111993/210276677-a84678a4-b75d-49bd-8561-96ad311a7050.png)
